<?php

include_once('database.php');
// include_once('functions.php');

// equipo ganador oficial
// $ganador = getEquipoGanador(2);
// echo $ganador;

// $compare = compareScore(3,1);
// if($compare){
//   echo '2 puntos';
// }else{
//   echo '1 punto';
// }

// equipo ganador del usuario

// $ganador = getEquipoGanadorUser(2);
// echo $ganador;


// for ($i=1; $i <= 18 ; $i++) { 
//   $sql = 'INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES ('. $i .', "1",' . $i . ', "-", "-");';
//   echo $sql;
// }

// for ($i=1; $i <= 18 ; $i++) { 
//   $sql = 'INSERT INTO user_goals_scored (user,fixture,team_a,team_b) VALUES ("19",' . $i . ', "-", "-");';
//   echo $sql;
// }

//INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (1, "1",1, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (2, "1",2, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (3, "1",3, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (4, "1",4, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (5, "1",5, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (6, "1",6, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (7, "1",7, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (8, "1",8, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (9, "1",9, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (10, "1",10, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (11, "1",11, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (12, "1",12, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (13, "1",13, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (14, "1",14, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (15, "1",15, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (16, "1",16, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (17, "1",17, "-", "-");INSERT INTO user_goals_scored (id,user,fixture,team_a,team_b) VALUES (18, "1",18, "-", "-");


//$sql = "INSERT INTO user_goals_scored (user,fixture,team_a,team_b) VALUES ('$id_user','$fixture_1', '$score_1_a', '$score_1_b');";
// $sql = "UPDATE user_goals_scored SET team_a = '$score_1_a', team_b = '$score_1_b' WHERE user = '$id_user' AND fixture = '$fixture_1'";

// consulta si el usuario ya ha ingresado su score anteriormente
	$stmt = "SELECT * FROM user_goals_scored WHERE user='1'";
	$result = $conexion->query($stmt);

	$count = $result->num_rows;

		if($count === 0){

			echo 'inserta datos';

		}else{

			echo 'actualiza datos';

		}
	


?>