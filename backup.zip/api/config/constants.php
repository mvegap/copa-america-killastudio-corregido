<?php

// constants
define('DB_HOST', 'localhost');
define('DB_USER', 'killa_dev');
define('DB_PASS', 'Cambiar01#_');
define('DB_NAME', 'killastudio_copaamerica');
define('DB_ENCODE', "utf8");

?>